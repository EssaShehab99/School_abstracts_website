<?php include('header.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carousel - Voler Admin Dashboard</title>
<!-- 
    <link rel="stylesheet" href="assets/css/bootstrap.css">

    <link rel="stylesheet" href="assets/vendors/perfect-scrollbar/perfect-scrollbar.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon"> -->
</head>

<body>





<div class="container" style="margin-top: 5%;margin-bottom: 5%;">

<?php for($i=0;$i<19;$i++){?>
      
    <div class="card mb-3">
            <img src="https://1.bp.blogspot.com/-lAY2BXFQYOc/XQVdF8cOyyI/AAAAAAAAF_k/vyoAQpoVuj04bdJogBYNj4qrgcf5Vna6QCLcBGAs/s1600/%25D9%2586%25D9%2585%25D8%25A7%25D8%25B0%25D8%25AC%2B%25D8%25A7%25D8%25AE%25D8%25AA%25D8%25A8%25D8%25A7%25D8%25B1%25D8%25A7%25D8%25AA%2B%25D9%2584%25D8%25BA%25D8%25A9%2B%25D8%25B9%25D8%25B1%25D8%25A8%25D9%258A%25D8%25A9%2B%25D8%25AB%25D8%25A7%25D9%2584%25D8%25AB%2B%25D8%25AB%25D8%25A7%25D9%2586%25D9%2588%25D9%258A%2B%25D8%25A7%25D9%2584%25D9%258A%25D9%2585%25D9%2586%2B%25D8%25A7%25D9%2584%25D9%2586%25D9%2585%25D9%2588%25D8%25B0%25D8%25AC%2B4%2B-2.jpg" class="card-img-top"height="600px" alt="..." />
            <div class="card-body">
                <h5 class="card-title">نماذج اختبارات</h5>
                <p class="card-text">
                "نموذج 4 لغة عربية - نماذج اختبارات وزارية ثالث ثانوي اليمن 2017","description": "السلام عليكم ورحمة الله وبركاته - نتمنى لجميع الطلاب بالتوفيق والنجاح واليكم النموذج الرابع لمادة اللغة العربية ثالث ثانوي اليمن 2017 كما
                </p>
                <p class="card-text">
                    <small class="text-muted">Last updated 3 mins ago</small>
                </p>
            </div>
        </div>
<?php }?>
    </div>





    <script src="assets/js/feather-icons/feather.min.js"></script>
    <script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>

    <script src="assets/js/main.js"></script>
</body>

</html>
<?php include("footer.php")?>
