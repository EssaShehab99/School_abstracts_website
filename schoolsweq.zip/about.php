<?php include('header.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carousel - Voler Admin Dashboard</title>
    <link href="assets/css/stylech.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/styleconnabou.css">

  
</head>

<body>

    <main>
      
    <section class="abt-08">
        <div class="containe">
            <div class="row">
                <div class="col12">
                    <div class="sting">
                        <h3> </h3>
                        <ol>
                            <!-- <li>Home <i class="fas fa-chevron-double-right"></i></li>
                            <li>Contact Us</li> -->
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <!-- =================bg-02 section================= -->

        <section class="bg-02">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="content">
                            <h2> أفضل منصة تعليمية</h2>

                            <p>نعمل على تقديم أفضل الخدمات التعليمية والملخصات المساعدة لتطوير مهارات الطلاب،
                            ايضاً نعمل على تنزيل شروحات للدروس التي يواجه فيها أعزأنا الطلاب صعوبات في الفهم.</p>

                            <p>من خدماتنا ايضاً متابعة آخر أخبار الوزارة ومن جميع المصادر الموثوقة.</p>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="content">
                            <div class="shap-img">
                                <img class="shap-img-1" src="image/1.jpeg">
                                <img class="shap-img-2" src="image/2.jpg">
                                <img class="shap-img-3" src="image/3.jpg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

</body>

</html>
<?php include("footer.php") ?>