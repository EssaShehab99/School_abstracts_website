<?php include('header.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carousel - Voler Admin Dashboard</title>
    <link href="assets/css/stylech.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/styleconnabou.css">



</head>

<body>

<section class="abt-08">
        <div class="containe">
            <div class="row">
                <div class="col12">
                    <div class="sting">
                        <h3> </h3>
                        <ol>
                            <!-- <li>Home <i class="fas fa-chevron-double-right"></i></li>
                            <li>Contact Us</li> -->
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ================**Contact  Section**================ -->

    <section class="bg-001">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="heading">
                        <h2>تواصل مع فريقنا</h2>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-12">
                    <div class="contact-box">
                        <ul>
                            <li>تواصل معنا على الفيسبوك</li>
                            <li>تواصل معنا على البريد الالكتروني</li>
                            <li>+967 777531859</li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-12">
                    <div class="contact-box">
                        <form action="" class="my-form">
                            <div class="form-group">
                                <input type="name" class="form-control" placeholder="الاسم">
                            </div>

                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="الايميل">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="الموضوع">
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" name="message" placeholder="الرسالة"></textarea>
                            </div>

                            <div class="form-group">
                                <div class="link">
                                    <a href="#">إرسال</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


</body>

</html>
<?php include("footer.php") ?>